package com.example.pedidosdemo20;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MisPedidosActivity extends AppCompatActivity
{
    private BottomNavigationView bottomNavigation;
    private LinearLayout llPerfil;
    private LinearLayout llPedidosEnCurso;

    private ImageView ivfotoPerfil;

    private ConstraintLayout constraintLayout;
    private boolean filtroPuesto = false;

    private String estadoREg = "registrado";
    private String estadoAct = "en curso";
    private String estadoREp = "en reparto";

    private LayoutInflater layoutInflater;
    private ScrollView svPedidosEnCurso;

    private ImageView ivIconoEstado;
    private TextView tvSinPedidos;
    private ImageView ivNuevoPedido;

    private RecyclerView rwPedidosEnCurso;

    private final ArrayList<Integer> alId = new ArrayList<>();
    private final ArrayList<String> alNumPedidoBSM = new ArrayList<>();
    private final ArrayList<String> alCia = new ArrayList<>();
    private final ArrayList<String> alCliente = new ArrayList<>();
    private final ArrayList<String> alEmail = new ArrayList<>();
    private final ArrayList<String> alFechaSolicitud = new ArrayList<>();
    private final ArrayList<String> alFechaEntrega = new ArrayList<>();
    private final ArrayList<String> alEstado = new ArrayList<>();

    private final ArrayList<Integer> alIdProducto = new ArrayList<>();
    private final ArrayList<Integer> alIdPedido = new ArrayList<>();
    private final ArrayList<Integer> alNumero = new ArrayList<>();
    private final ArrayList<String> alFormato = new ArrayList<>();
    private final ArrayList<String> alLinea = new ArrayList<>();

    private String clave = "";
    private String nombre = "pedidos_kubus";
    private String password = "C4lleV@rsov1a.,:";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_pedidos);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        llPerfil = findViewById(R.id.llPerfil);
        llPedidosEnCurso = findViewById(R.id.llPedidosEnCurso);

        rwPedidosEnCurso = findViewById(R.id.rwPedidosEnCurso);
        svPedidosEnCurso = findViewById(R.id.svPedidosEnCurso);

        bottomNavigation = findViewById(R.id.bottomNavigation);
        bottomNavigation.setSelectedItemId(R.id.itMisPedidos);

        ivIconoEstado = findViewById(R.id.ivIconoEstado);
        tvSinPedidos = findViewById(R.id.tvSinPedidos);
        ivNuevoPedido = findViewById(R.id.ivNuevoPedido);

        layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        bottomNavigation.setOnItemSelectedListener(item -> {
            switch (item.getItemId())
            {
                case R.id.itMisPedidos:

                    return true;
                case R.id.itNuevoPedido:
                    startActivity(new Intent(getApplicationContext(), NuevoPedidoActivity.class));
                    //overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
                case R.id.itNeveras:
                    startActivity(new Intent(getApplicationContext(), NeveraActivity.class));
                    //overridePendingTransition(R.anim.slide_out_left, R.anim.slide_in_right);
                    finish();
                    return true;
            }
            return false;
        });

        establecerPestanaPerfil();
        establecerPedidosEnCurso();
    }

    private void establecerPedidosEnCurso()
    {
        RequestQueue queue = Volley.newRequestQueue(this);

        //svPedidosEnCurso.setVisibility(View.INVISIBLE);

        final JSONObject jsonObj = new JSONObject();
        //String rega = pedidosDB.rega();
        try
        {
            jsonObj.put("estado", "registrado");
            jsonObj.put("estado2", "en curso");
            jsonObj.put("estado3", "en reparto");
            jsonObj.put("email", "data@kubus.es");
            //jsonObj.put("email", email);
            jsonObj.put("rega", "ES001");
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        String urlRecogerPedido = "https://connect.animalsat.com/api/pedidosDeUserBeta2";

        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, urlRecogerPedido, jsonObj, new Response.Listener<JSONObject>()
        {
            @Override
            public void onResponse(JSONObject response)
            {
                JSONArray jsonArray = null;

                try
                {
                    jsonArray = response.getJSONArray("response");
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }

                JSONObject jsonObjectID;
                JSONObject jsonObject;
                int id;
                String cia;
                String numPedido;
                String cliente;
                String fechaSolicitud;
                String fechaEntrega;
                String estado;
                int contador = 0;

                int idPro;
                int idPedido;
                int numero;
                String formato;
                String linea;

                if (jsonArray != null)
                {
                    tvSinPedidos.setVisibility(View.INVISIBLE);
                    ivIconoEstado.setVisibility(View.INVISIBLE);
                    ivNuevoPedido.setVisibility(View.INVISIBLE);

                    for (int i = 0; i < jsonArray.length(); i++)
                    {
                        try
                        {
                            jsonObjectID = jsonArray.getJSONObject(i);

                            id = Integer.parseInt(jsonObjectID.getString("id"));
                            alId.add(id);

                            numPedido = jsonObjectID.getString("numPedidoBSM");
                            alNumPedidoBSM.add(numPedido);

                            cia = jsonObjectID.getString("cia");
                            alCia.add(cia);

                            cliente = jsonObjectID.getString("cliente");
                            alCliente.add(cliente);

                            fechaSolicitud = jsonObjectID.getString("fechaSolicitud");
                            fechaSolicitud = fechaSolicitud.substring(0, 4) + "/" + fechaSolicitud.substring(4, 6) + "/" + fechaSolicitud.substring(6, 8);
                            alFechaSolicitud.add(fechaSolicitud);

                            fechaEntrega = jsonObjectID.getString("fechaEntrega");
                            fechaEntrega = fechaEntrega.substring(0, 4) + "/" + fechaEntrega.substring(4, 6) + "/" + fechaEntrega.substring(6, 8);
                            alFechaEntrega.add(fechaEntrega);

                            estado = jsonObjectID.getString("estado");
                            alEstado.add(estado);

                            JSONArray jsonArray1 = jsonArray.getJSONObject(i).getJSONArray("Productos");
                            for (int j = 0; j < jsonArray1.length(); j++)
                            {
                                jsonObject = jsonArray1.getJSONObject(j);

                                idPro = Integer.parseInt(jsonObject.getString("id"));
                                alIdProducto.add(idPro);

                                idPedido = Integer.parseInt(jsonObject.getString("idPedido"));
                                alIdPedido.add(idPedido);

                                numero = Integer.parseInt(jsonObject.getString("numero"));
                                alNumero.add(numero);

                                formato = jsonObject.getString("formato");
                                alFormato.add(formato);

                                linea = jsonObject.getString("linea");
                                alLinea.add(linea);
                            }
                            contador++;
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }

                        if (contador == jsonArray.length())
                        {
                            dibujarPedidos();
                        }
                    }
                }
                else {
                    tvSinPedidos.setVisibility(View.VISIBLE);
                    ivIconoEstado.setVisibility(View.VISIBLE);
                    ivNuevoPedido.setVisibility(View.VISIBLE);
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error)
            {
                /*View view = new View(MainActivity.this);
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                view = getLayoutInflater().inflate(R.layout.item_sin_conexion, null);
                builder.setView(view);

                TextView tvOk = view.findViewById(R.id.tvOk);

                final AlertDialog alertDialog = builder.create();

                tvOk.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        alertDialog.dismiss();
                    }
                });

                alertDialog.show();
                Log.d("TAG", "Error = "+ error);*/
            }
        })
        {

            @Override
            public byte[] getBody() {
                try
                {
                    return jsonObj.toString() == null ? null : jsonObj.toString().getBytes("utf-8");
                }
                catch (UnsupportedEncodingException uee)
                {
                    //Log.v("Unsupported Encoding while trying to get the bytes", data);
                    return null;
                }
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError
            {
                Map<String, String> headers = new HashMap<>();
                clave = "Basic " + Base64.encodeToString((nombre + ":" + password).getBytes(), Base64.NO_WRAP);
                headers.put("Authorization", clave);
                headers.put("Content-Type", "application/json");
                return headers;
            }
        };
        queue.add(stringRequest);

        Log.d( "js", stringRequest.toString());
    }

    private void dibujarPedidos()
    {
        int size = alId.size();

        if (size == 0)
        {

        }
        else
        {
            //tvSinPedidos.setVisibility(View.INVISIBLE);
            for (int i = 0; i < size; i++)
            {
                ConstraintLayout constraintLayout = (ConstraintLayout) layoutInflater.inflate(R.layout.item_pedido_en_progreso, null);

                TextView tvEstadoPedido = constraintLayout.findViewById(R.id.tvEstadoPedido);
                ImageView ivIconoEstado = constraintLayout.findViewById(R.id.ivIconoEstado);
                LinearLayout llProductos = constraintLayout.findViewById(R.id.llProductos);
                TextView tvFecha = constraintLayout.findViewById(R.id.tvFecha);
                TextView tvFechaPedido = constraintLayout.findViewById(R.id.tvFechaPedido);
                ImageView ivVerPedido = constraintLayout.findViewById(R.id.ivVerPedido);
                ImageView ivRepetirPedido = constraintLayout.findViewById(R.id.ivRepetirPedido);
                ImageView ivFavorito = constraintLayout.findViewById(R.id.ivFavorito);

                String estado = alEstado.get(i);
                String url = "";
                if (estado.equals(estadoAct))
                {
                    url = "https://www.kubus-sa.com/wp-content/uploads/2023/06/Confirmado.gif";
                    tvEstadoPedido.setBackgroundColor(getResources().getColor(R.color.naranja));
                    tvEstadoPedido.setText(R.string.pedidoConfirmado);
                }
                else if (estado.equals(estadoREg))
                {
                    url = "https://www.kubus-sa.com/wp-content/uploads/2023/06/Espera.gif";
                    tvEstadoPedido.setBackgroundColor(getResources().getColor(R.color.rojo));
                    tvEstadoPedido.setText(R.string.pedidoEnEspera);
                }
                else
                {
                    url = "https://www.kubus-sa.com/wp-content/uploads/2023/06/En-reparto_1.gif";
                    tvEstadoPedido.setBackgroundColor(getResources().getColor(R.color.azul));
                    tvEstadoPedido.setText(R.string.pedidoEnReparto);
                }

                Uri uri = Uri.parse(url);
                Glide.with(getApplicationContext()).load(uri).into(ivIconoEstado);

                tvFecha.setText(R.string.fechaPrevistaEntrega);
                tvFechaPedido.setText(alFechaEntrega.get(i));

                for (int j = 0; j < alIdProducto.size(); j++)
                {
                    ConstraintLayout constraintLayout1 = (ConstraintLayout) layoutInflater.inflate(R.layout.item_productos, null);

                    TextView tvNumdosis = constraintLayout1.findViewById(R.id.tvNumdosis);
                    TextView tvLineaGenetica = constraintLayout1.findViewById(R.id.tvLineaGenetica);
                    TextView tvFormato = constraintLayout1.findViewById(R.id.tvFormato);

                    int idPed = alIdPedido.get(j);
                    int id = alId.get(i);

                    if (idPed == id)
                    {
                        tvNumdosis.setText(alNumero.get(j) + "");
                        tvLineaGenetica.setText(alLinea.get(j));
                        tvFormato.setText(alFormato.get(j));

                        llProductos.addView(constraintLayout1);
                    }
                }
                llPedidosEnCurso.addView(constraintLayout);
            }
        }
    }

    private void establecerPestanaPerfil()
    {
        constraintLayout = (ConstraintLayout) layoutInflater.inflate(R.layout.item_ficha_personal, null);

        ivfotoPerfil = constraintLayout.findViewById(R.id.ivfotoPerfil);
        TextView tvNombreGranja = constraintLayout.findViewById(R.id.tvNombreGranja);
        TextView tvFecha = constraintLayout.findViewById(R.id.tvFecha);
        ImageView ivAjustes = constraintLayout.findViewById(R.id.ivAjustes);
        TextView tvNombreUsuario = constraintLayout.findViewById(R.id.tvNombreUsuario);
        ImageView ivPEdidosEncurso = constraintLayout.findViewById(R.id.ivPEdidosEncurso);
        ImageView ivPEdidosEntregados = constraintLayout.findViewById(R.id.ivPEdidosEntregados);

        ivfotoPerfil.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                cargarImagen();
            }
        });

        ivPEdidosEncurso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                ivPEdidosEntregados.setImageResource(R.drawable.ic_bot_n_entregados_sin_activar);
                ivPEdidosEncurso.setImageResource(R.drawable.ic_pedidos_en_curso_activados);
                ConstraintLayout segundoConstraintLayout = (ConstraintLayout) llPerfil.getChildAt(1);
                if (filtroPuesto)
                {
                    llPerfil.removeView(segundoConstraintLayout);
                    filtroPuesto = false;
                }
                establecerPedidosEnCurso();
            }
        });

        ivPEdidosEntregados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                tvSinPedidos.setVisibility(View.INVISIBLE);
                ivIconoEstado.setVisibility(View.INVISIBLE);
                ivNuevoPedido.setVisibility(View.INVISIBLE);
                ivPEdidosEntregados.setImageResource(R.drawable.ic_pedidos_entregados);
                ivPEdidosEncurso.setImageResource(R.drawable.ic_pedidos_en_curso);
                if (!filtroPuesto)
                {
                    establecerFiltrado();
                    filtroPuesto = true;
                }
            }
        });

        llPerfil.addView(constraintLayout);
    }

    private void cargarImagen()
    {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/");
        startActivity(intent.createChooser(intent,"Seleccione app"));
    }

    ActivityResultLauncher<Integer> launcher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null) {
                        int resultValue = data.getIntExtra("key", defaultValue);
                        // Manejar el resultado obtenido
                    }
                }
            });

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
            Uri path = data.getData();
            ivfotoPerfil.setImageURI(path);
    }

    private void establecerFiltrado()
    {
        constraintLayout = (ConstraintLayout) layoutInflater.inflate(R.layout.item_filtrado_pedidos, null);

        ImageView ivPedidosFav = constraintLayout.findViewById(R.id.ivPedidosFav);
        ImageView ivPEdidosFech = constraintLayout.findViewById(R.id.ivPEdidosFech);
        ImageView ivPedidosLin = constraintLayout.findViewById(R.id.ivPedidosLin);
        ImageView ivPedidosFor = constraintLayout.findViewById(R.id.ivPedidosFor);

        llPerfil.addView(constraintLayout);
    }
}